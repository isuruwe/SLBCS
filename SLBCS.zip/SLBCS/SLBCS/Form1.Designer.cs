﻿
namespace SLBCS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.changeLocationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.arrivalsDeparturesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.disembarcationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.embacationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.referalOfficeClearanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leavingForGoodToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.crewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.impoundsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.flightDelaysToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transfersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.passengerCrewCancellationsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deporteesRemovalsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.passengerInspectionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.flightCrewInspectionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.electronicTravelAuthorizationETAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eTAExcemptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelOnArrivalETAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shipPassengerInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inactiveOnWebToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visaStickerProcessToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.baclogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.bondsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prosecutionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maintananceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.performanceAnalysisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imagesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.overStaysToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miscelaneousToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.messagesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.windowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.imigrationDataSet = new SLBCS.ImigrationDataSet();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.borderMasterBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.imigrationDataSet1 = new SLBCS.ImigrationDataSet1();
            this.panel8 = new System.Windows.Forms.Panel();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.borderMasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.imigrationDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.imigrationDataSet2 = new SLBCS.ImigrationDataSet2();
            this.imigrationDataSet2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.borderMasterTableAdapter = new SLBCS.ImigrationDataSet1TableAdapters.BorderMasterTableAdapter();
            this.startOfDayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.endOfDayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeStickerNumberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.damageStickersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stickerInqueryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sAOProcessEODToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aODailyAttendanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stickerEODBySAOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shipClearanceStickerIssueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imigrationDataSet)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.borderMasterBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imigrationDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.borderMasterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imigrationDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imigrationDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imigrationDataSet2BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(20, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(295, 55);
            this.label1.TabIndex = 7;
            this.label1.Text = "ආයුබෝවන්!";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(338, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(277, 55);
            this.label2.TabIndex = 8;
            this.label2.Text = "வணக்கம்! ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Stencil Std", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(614, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(295, 38);
            this.label3.TabIndex = 9;
            this.label3.Text = "BORDER CONTROL";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(766, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 24);
            this.label4.TabIndex = 10;
            this.label4.Text = "Reminders!";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.arrivalsDeparturesToolStripMenuItem,
            this.bondsToolStripMenuItem,
            this.prosecutionToolStripMenuItem,
            this.paymentsToolStripMenuItem,
            this.maintananceToolStripMenuItem,
            this.performanceAnalysisToolStripMenuItem,
            this.imagesToolStripMenuItem,
            this.overStaysToolStripMenuItem,
            this.miscelaneousToolStripMenuItem,
            this.messagesToolStripMenuItem,
            this.testingToolStripMenuItem,
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.windowToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(20, 30);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1326, 24);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.changeLocationToolStripMenuItem});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(58, 20);
            this.toolStripMenuItem3.Text = "Utilities";
            // 
            // changeLocationToolStripMenuItem
            // 
            this.changeLocationToolStripMenuItem.Name = "changeLocationToolStripMenuItem";
            this.changeLocationToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.changeLocationToolStripMenuItem.Text = "Change Location";
            this.changeLocationToolStripMenuItem.Click += new System.EventHandler(this.changeLocationToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(65, 20);
            this.toolStripMenuItem4.Text = "Statistics";
            // 
            // arrivalsDeparturesToolStripMenuItem
            // 
            this.arrivalsDeparturesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.disembarcationToolStripMenuItem,
            this.embacationToolStripMenuItem,
            this.referalOfficeClearanceToolStripMenuItem,
            this.leavingForGoodToolStripMenuItem,
            this.transitToolStripMenuItem,
            this.crewToolStripMenuItem,
            this.impoundsToolStripMenuItem,
            this.formXToolStripMenuItem,
            this.flightDelaysToolStripMenuItem,
            this.transfersToolStripMenuItem,
            this.passengerCrewCancellationsToolStripMenuItem,
            this.deporteesRemovalsToolStripMenuItem,
            this.passengerInspectionsToolStripMenuItem,
            this.flightCrewInspectionsToolStripMenuItem,
            this.electronicTravelAuthorizationETAToolStripMenuItem,
            this.eTAExcemptToolStripMenuItem,
            this.cancelOnArrivalETAToolStripMenuItem,
            this.shipPassengerInformationToolStripMenuItem,
            this.inactiveOnWebToolStripMenuItem,
            this.visaStickerProcessToolStripMenuItem,
            this.baclogToolStripMenuItem,
            this.toolStripMenuItem5,
            this.toolStripMenuItem6});
            this.arrivalsDeparturesToolStripMenuItem.Name = "arrivalsDeparturesToolStripMenuItem";
            this.arrivalsDeparturesToolStripMenuItem.Size = new System.Drawing.Size(120, 20);
            this.arrivalsDeparturesToolStripMenuItem.Text = "Arrivals/Departures";
            // 
            // disembarcationToolStripMenuItem
            // 
            this.disembarcationToolStripMenuItem.Name = "disembarcationToolStripMenuItem";
            this.disembarcationToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.disembarcationToolStripMenuItem.Text = "Disembarkation Counter";
            this.disembarcationToolStripMenuItem.Click += new System.EventHandler(this.disembarcationToolStripMenuItem_Click);
            // 
            // embacationToolStripMenuItem
            // 
            this.embacationToolStripMenuItem.Name = "embacationToolStripMenuItem";
            this.embacationToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.embacationToolStripMenuItem.Text = "Embakation Counter";
            this.embacationToolStripMenuItem.Click += new System.EventHandler(this.embacationToolStripMenuItem_Click);
            // 
            // referalOfficeClearanceToolStripMenuItem
            // 
            this.referalOfficeClearanceToolStripMenuItem.Name = "referalOfficeClearanceToolStripMenuItem";
            this.referalOfficeClearanceToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.referalOfficeClearanceToolStripMenuItem.Text = "Referal Office Clearance";
            // 
            // leavingForGoodToolStripMenuItem
            // 
            this.leavingForGoodToolStripMenuItem.Name = "leavingForGoodToolStripMenuItem";
            this.leavingForGoodToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.leavingForGoodToolStripMenuItem.Text = "Leaving for Good";
            // 
            // transitToolStripMenuItem
            // 
            this.transitToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem});
            this.transitToolStripMenuItem.Name = "transitToolStripMenuItem";
            this.transitToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.transitToolStripMenuItem.Text = "Transit";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.newToolStripMenuItem.Text = "New";
            // 
            // crewToolStripMenuItem
            // 
            this.crewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem1});
            this.crewToolStripMenuItem.Name = "crewToolStripMenuItem";
            this.crewToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.crewToolStripMenuItem.Text = "Crew";
            // 
            // newToolStripMenuItem1
            // 
            this.newToolStripMenuItem1.Name = "newToolStripMenuItem1";
            this.newToolStripMenuItem1.Size = new System.Drawing.Size(98, 22);
            this.newToolStripMenuItem1.Text = "New";
            // 
            // impoundsToolStripMenuItem
            // 
            this.impoundsToolStripMenuItem.Name = "impoundsToolStripMenuItem";
            this.impoundsToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.impoundsToolStripMenuItem.Text = "Impounds";
            // 
            // formXToolStripMenuItem
            // 
            this.formXToolStripMenuItem.Name = "formXToolStripMenuItem";
            this.formXToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.formXToolStripMenuItem.Text = "Form-X";
            // 
            // flightDelaysToolStripMenuItem
            // 
            this.flightDelaysToolStripMenuItem.Name = "flightDelaysToolStripMenuItem";
            this.flightDelaysToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.flightDelaysToolStripMenuItem.Text = "Flight Delays";
            // 
            // transfersToolStripMenuItem
            // 
            this.transfersToolStripMenuItem.Name = "transfersToolStripMenuItem";
            this.transfersToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.transfersToolStripMenuItem.Text = "Transfers";
            // 
            // passengerCrewCancellationsToolStripMenuItem
            // 
            this.passengerCrewCancellationsToolStripMenuItem.Name = "passengerCrewCancellationsToolStripMenuItem";
            this.passengerCrewCancellationsToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.passengerCrewCancellationsToolStripMenuItem.Text = "Passenger/Crew Cancellations";
            // 
            // deporteesRemovalsToolStripMenuItem
            // 
            this.deporteesRemovalsToolStripMenuItem.Name = "deporteesRemovalsToolStripMenuItem";
            this.deporteesRemovalsToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.deporteesRemovalsToolStripMenuItem.Text = "Deportees/Removals";
            // 
            // passengerInspectionsToolStripMenuItem
            // 
            this.passengerInspectionsToolStripMenuItem.Name = "passengerInspectionsToolStripMenuItem";
            this.passengerInspectionsToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.passengerInspectionsToolStripMenuItem.Text = "Passenger Inspections";
            // 
            // flightCrewInspectionsToolStripMenuItem
            // 
            this.flightCrewInspectionsToolStripMenuItem.Name = "flightCrewInspectionsToolStripMenuItem";
            this.flightCrewInspectionsToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.flightCrewInspectionsToolStripMenuItem.Text = "Ship/Flight Inspections";
            this.flightCrewInspectionsToolStripMenuItem.Click += new System.EventHandler(this.flightCrewInspectionsToolStripMenuItem_Click);
            // 
            // electronicTravelAuthorizationETAToolStripMenuItem
            // 
            this.electronicTravelAuthorizationETAToolStripMenuItem.Name = "electronicTravelAuthorizationETAToolStripMenuItem";
            this.electronicTravelAuthorizationETAToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.electronicTravelAuthorizationETAToolStripMenuItem.Text = "Electronic Travel Authorization (ETA)";
            // 
            // eTAExcemptToolStripMenuItem
            // 
            this.eTAExcemptToolStripMenuItem.Name = "eTAExcemptToolStripMenuItem";
            this.eTAExcemptToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.eTAExcemptToolStripMenuItem.Text = "ETA Excempt";
            // 
            // cancelOnArrivalETAToolStripMenuItem
            // 
            this.cancelOnArrivalETAToolStripMenuItem.Name = "cancelOnArrivalETAToolStripMenuItem";
            this.cancelOnArrivalETAToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.cancelOnArrivalETAToolStripMenuItem.Text = "Cancel on Arrival ETA";
            // 
            // shipPassengerInformationToolStripMenuItem
            // 
            this.shipPassengerInformationToolStripMenuItem.Name = "shipPassengerInformationToolStripMenuItem";
            this.shipPassengerInformationToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.shipPassengerInformationToolStripMenuItem.Text = "Ship Passenger Information";
            // 
            // inactiveOnWebToolStripMenuItem
            // 
            this.inactiveOnWebToolStripMenuItem.Name = "inactiveOnWebToolStripMenuItem";
            this.inactiveOnWebToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.inactiveOnWebToolStripMenuItem.Text = "Inactive Web/ On Arrival ETA";
            // 
            // visaStickerProcessToolStripMenuItem
            // 
            this.visaStickerProcessToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem2,
            this.startOfDayToolStripMenuItem,
            this.endOfDayToolStripMenuItem,
            this.changeStickerNumberToolStripMenuItem,
            this.damageStickersToolStripMenuItem,
            this.stickerInqueryToolStripMenuItem,
            this.sAOProcessEODToolStripMenuItem,
            this.aODailyAttendanceToolStripMenuItem,
            this.stickerEODBySAOToolStripMenuItem,
            this.shipClearanceStickerIssueToolStripMenuItem});
            this.visaStickerProcessToolStripMenuItem.Name = "visaStickerProcessToolStripMenuItem";
            this.visaStickerProcessToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.visaStickerProcessToolStripMenuItem.Text = "Visa Sticker Process";
            // 
            // newToolStripMenuItem2
            // 
            this.newToolStripMenuItem2.Name = "newToolStripMenuItem2";
            this.newToolStripMenuItem2.Size = new System.Drawing.Size(219, 22);
            this.newToolStripMenuItem2.Text = "VISA Sticker Issue";
            // 
            // baclogToolStripMenuItem
            // 
            this.baclogToolStripMenuItem.Enabled = false;
            this.baclogToolStripMenuItem.Name = "baclogToolStripMenuItem";
            this.baclogToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.baclogToolStripMenuItem.Text = "Baclog";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Enabled = false;
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(315, 22);
            this.toolStripMenuItem5.Text = "ETA SAO Approval for Bussiness Puropos VISA";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Enabled = false;
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(315, 22);
            this.toolStripMenuItem6.Text = "ETA SAO Approval for CHOGAM";
            // 
            // bondsToolStripMenuItem
            // 
            this.bondsToolStripMenuItem.Name = "bondsToolStripMenuItem";
            this.bondsToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.bondsToolStripMenuItem.Text = "Bonds";
            // 
            // prosecutionToolStripMenuItem
            // 
            this.prosecutionToolStripMenuItem.Name = "prosecutionToolStripMenuItem";
            this.prosecutionToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
            this.prosecutionToolStripMenuItem.Text = "Prosecution";
            // 
            // paymentsToolStripMenuItem
            // 
            this.paymentsToolStripMenuItem.Name = "paymentsToolStripMenuItem";
            this.paymentsToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.paymentsToolStripMenuItem.Text = "Payments";
            // 
            // maintananceToolStripMenuItem
            // 
            this.maintananceToolStripMenuItem.Name = "maintananceToolStripMenuItem";
            this.maintananceToolStripMenuItem.Size = new System.Drawing.Size(88, 20);
            this.maintananceToolStripMenuItem.Text = "Maintanance";
            // 
            // performanceAnalysisToolStripMenuItem
            // 
            this.performanceAnalysisToolStripMenuItem.Name = "performanceAnalysisToolStripMenuItem";
            this.performanceAnalysisToolStripMenuItem.Size = new System.Drawing.Size(133, 20);
            this.performanceAnalysisToolStripMenuItem.Text = "Performance Analysis";
            // 
            // imagesToolStripMenuItem
            // 
            this.imagesToolStripMenuItem.Name = "imagesToolStripMenuItem";
            this.imagesToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.imagesToolStripMenuItem.Text = "Images";
            // 
            // overStaysToolStripMenuItem
            // 
            this.overStaysToolStripMenuItem.Name = "overStaysToolStripMenuItem";
            this.overStaysToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.overStaysToolStripMenuItem.Text = "Overstays";
            this.overStaysToolStripMenuItem.Click += new System.EventHandler(this.overStaysToolStripMenuItem_Click);
            // 
            // miscelaneousToolStripMenuItem
            // 
            this.miscelaneousToolStripMenuItem.Name = "miscelaneousToolStripMenuItem";
            this.miscelaneousToolStripMenuItem.Size = new System.Drawing.Size(91, 20);
            this.miscelaneousToolStripMenuItem.Text = "Miscelaneous";
            // 
            // messagesToolStripMenuItem
            // 
            this.messagesToolStripMenuItem.Name = "messagesToolStripMenuItem";
            this.messagesToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.messagesToolStripMenuItem.Text = "Messages";
            // 
            // testingToolStripMenuItem
            // 
            this.testingToolStripMenuItem.Name = "testingToolStripMenuItem";
            this.testingToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.testingToolStripMenuItem.Text = "Testing";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(52, 20);
            this.toolStripMenuItem1.Text = "About";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(38, 20);
            this.toolStripMenuItem2.Text = "Exit";
            // 
            // windowToolStripMenuItem
            // 
            this.windowToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loginToolStripMenuItem});
            this.windowToolStripMenuItem.Name = "windowToolStripMenuItem";
            this.windowToolStripMenuItem.Size = new System.Drawing.Size(63, 20);
            this.windowToolStripMenuItem.Text = "Window";
            // 
            // loginToolStripMenuItem
            // 
            this.loginToolStripMenuItem.Name = "loginToolStripMenuItem";
            this.loginToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.loginToolStripMenuItem.Text = "Location";
            this.loginToolStripMenuItem.Click += new System.EventHandler(this.loginToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.pictureBox8);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Location = new System.Drawing.Point(20, 79);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1041, 607);
            this.panel1.TabIndex = 13;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::SLBCS.Properties.Resources.download;
            this.pictureBox8.Location = new System.Drawing.Point(922, 485);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(112, 120);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 11;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SLBCS.Properties.Resources._37459194451_4d0757c874_b;
            this.pictureBox2.Location = new System.Drawing.Point(195, 211);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(169, 124);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SLBCS.Properties.Resources.sri_dalada_maligawa_or;
            this.pictureBox1.Location = new System.Drawing.Point(28, 87);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(166, 124);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::SLBCS.Properties.Resources.sigiriya_4;
            this.pictureBox3.Location = new System.Drawing.Point(364, 87);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(169, 124);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::SLBCS.Properties.Resources.San_Diego_International_Airport_Terminal_2_3;
            this.pictureBox4.Location = new System.Drawing.Point(533, 212);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(169, 124);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::SLBCS.Properties.Resources.daf5fd18c05264f793a0accf148695ca;
            this.pictureBox5.Location = new System.Drawing.Point(30, 334);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(166, 124);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::SLBCS.Properties.Resources.Avukana_Buddha_Statue;
            this.pictureBox7.Location = new System.Drawing.Point(702, 335);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(169, 124);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 6;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::SLBCS.Properties.Resources.tea_plantations_in_Haputale;
            this.pictureBox6.Location = new System.Drawing.Point(364, 334);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(169, 124);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 5;
            this.pictureBox6.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Blue;
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(20, 55);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1041, 25);
            this.panel2.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(5, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(176, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "BORDER CONTROL SYSTEM";
            // 
            // imigrationDataSet
            // 
            this.imigrationDataSet.DataSetName = "ImigrationDataSet";
            this.imigrationDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(20, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(295, 55);
            this.label9.TabIndex = 7;
            this.label9.Text = "ආයුබෝවන්!";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(338, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(277, 55);
            this.label8.TabIndex = 8;
            this.label8.Text = "வணக்கம்! ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Stencil Std", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(613, 85);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(295, 38);
            this.label7.TabIndex = 9;
            this.label7.Text = "BORDER CONTROL";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(851, 124);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 24);
            this.label6.TabIndex = 10;
            this.label6.Text = "Reminders!";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.dataGridView1);
            this.panel3.Controls.Add(this.panel8);
            this.panel3.Controls.Add(this.pictureBox9);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Location = new System.Drawing.Point(21, 81);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1040, 664);
            this.panel3.TabIndex = 15;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(634, 55);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(0, 24);
            this.label15.TabIndex = 26;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(737, 636);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(87, 13);
            this.label14.TabIndex = 25;
            this.label14.Text = "Selected Record";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.statusDataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.Status,
            this.dataGridViewTextBoxColumn6,
            this.Column1});
            this.dataGridView1.DataSource = this.borderMasterBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(3, 146);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.Size = new System.Drawing.Size(793, 454);
            this.dataGridView1.TabIndex = 12;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // borderMasterBindingSource1
            // 
            this.borderMasterBindingSource1.DataMember = "BorderMaster";
            this.borderMasterBindingSource1.DataSource = this.imigrationDataSet1;
            // 
            // imigrationDataSet1
            // 
            this.imigrationDataSet1.DataSetName = "ImigrationDataSet1";
            this.imigrationDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Cyan;
            this.panel8.Location = new System.Drawing.Point(697, 633);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(16, 15);
            this.panel8.TabIndex = 24;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::SLBCS.Properties.Resources.download;
            this.pictureBox9.Location = new System.Drawing.Point(831, 483);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(112, 120);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 11;
            this.pictureBox9.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(577, 635);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(96, 13);
            this.label13.TabIndex = 23;
            this.label13.Text = "Approved Records";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Lime;
            this.panel7.Location = new System.Drawing.Point(544, 634);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(16, 15);
            this.panel7.TabIndex = 22;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(419, 636);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(93, 13);
            this.label12.TabIndex = 21;
            this.label12.Text = "Rejected Records";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Red;
            this.panel6.Location = new System.Drawing.Point(386, 634);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(16, 15);
            this.panel6.TabIndex = 20;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(274, 636);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(89, 13);
            this.label11.TabIndex = 19;
            this.label11.Text = "Pending Records";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Location = new System.Drawing.Point(243, 634);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(16, 15);
            this.panel5.TabIndex = 18;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Fuchsia;
            this.panel4.Location = new System.Drawing.Point(17, 634);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(18, 15);
            this.panel4.TabIndex = 16;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(41, 636);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(180, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "AC Approved and SAO Noti.Pending";
            // 
            // borderMasterBindingSource
            // 
            this.borderMasterBindingSource.DataMember = "BorderMaster";
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.HeaderText = "Column1";
            this.dataGridViewImageColumn1.Image = global::SLBCS.Properties.Resources.icons8_chevron_right_24;
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.ReadOnly = true;
            this.dataGridViewImageColumn1.Width = 30;
            // 
            // imigrationDataSetBindingSource
            // 
            this.imigrationDataSetBindingSource.DataSource = this.imigrationDataSet;
            this.imigrationDataSetBindingSource.Position = 0;
            // 
            // imigrationDataSet2
            // 
            this.imigrationDataSet2.DataSetName = "ImigrationDataSet2";
            this.imigrationDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // imigrationDataSet2BindingSource
            // 
            this.imigrationDataSet2BindingSource.DataSource = this.imigrationDataSet2;
            this.imigrationDataSet2BindingSource.Position = 0;
            // 
            // borderMasterTableAdapter
            // 
            this.borderMasterTableAdapter.ClearBeforeFill = true;
            // 
            // startOfDayToolStripMenuItem
            // 
            this.startOfDayToolStripMenuItem.Name = "startOfDayToolStripMenuItem";
            this.startOfDayToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.startOfDayToolStripMenuItem.Text = "Start of Day";
            // 
            // endOfDayToolStripMenuItem
            // 
            this.endOfDayToolStripMenuItem.Name = "endOfDayToolStripMenuItem";
            this.endOfDayToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.endOfDayToolStripMenuItem.Text = "End of Day";
            // 
            // changeStickerNumberToolStripMenuItem
            // 
            this.changeStickerNumberToolStripMenuItem.Name = "changeStickerNumberToolStripMenuItem";
            this.changeStickerNumberToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.changeStickerNumberToolStripMenuItem.Text = "Change Sticker Number";
            // 
            // damageStickersToolStripMenuItem
            // 
            this.damageStickersToolStripMenuItem.Name = "damageStickersToolStripMenuItem";
            this.damageStickersToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.damageStickersToolStripMenuItem.Text = "Damage Stickers";
            // 
            // stickerInqueryToolStripMenuItem
            // 
            this.stickerInqueryToolStripMenuItem.Name = "stickerInqueryToolStripMenuItem";
            this.stickerInqueryToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.stickerInqueryToolStripMenuItem.Text = "Sticker Inquery";
            // 
            // sAOProcessEODToolStripMenuItem
            // 
            this.sAOProcessEODToolStripMenuItem.Name = "sAOProcessEODToolStripMenuItem";
            this.sAOProcessEODToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.sAOProcessEODToolStripMenuItem.Text = "SAO-Process EOD";
            // 
            // aODailyAttendanceToolStripMenuItem
            // 
            this.aODailyAttendanceToolStripMenuItem.Name = "aODailyAttendanceToolStripMenuItem";
            this.aODailyAttendanceToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.aODailyAttendanceToolStripMenuItem.Text = "AO Daily Attendance";
            // 
            // stickerEODBySAOToolStripMenuItem
            // 
            this.stickerEODBySAOToolStripMenuItem.Name = "stickerEODBySAOToolStripMenuItem";
            this.stickerEODBySAOToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.stickerEODBySAOToolStripMenuItem.Text = "Sticker EOD by SAO";
            // 
            // shipClearanceStickerIssueToolStripMenuItem
            // 
            this.shipClearanceStickerIssueToolStripMenuItem.Name = "shipClearanceStickerIssueToolStripMenuItem";
            this.shipClearanceStickerIssueToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.shipClearanceStickerIssueToolStripMenuItem.Text = "Ship Clearance Sticker Issue";
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            this.statusDataGridViewTextBoxColumn.ReadOnly = true;
            this.statusDataGridViewTextBoxColumn.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "PassportNo";
            this.dataGridViewTextBoxColumn1.HeaderText = "PassportNo";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Nationality";
            this.dataGridViewTextBoxColumn2.HeaderText = "Nationality";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Reason";
            this.dataGridViewTextBoxColumn3.HeaderText = "Reason";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 200;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Counrt";
            this.dataGridViewTextBoxColumn4.HeaderText = "Counter";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "createddate";
            this.dataGridViewTextBoxColumn5.HeaderText = "Date";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 150;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.Visible = false;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "loggeduser";
            this.dataGridViewTextBoxColumn6.HeaderText = "User";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "";
            this.Column1.Image = global::SLBCS.Properties.Resources.icons8_chevron_right_24;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 30;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1366, 768);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.DisplayHeader = false;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.TransparencyKey = System.Drawing.Color.Empty;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imigrationDataSet)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.borderMasterBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imigrationDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.borderMasterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imigrationDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imigrationDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imigrationDataSet2BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem windowToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginToolStripMenuItem;
        public System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ToolStripMenuItem arrivalsDeparturesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem disembarcationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem embacationToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox8;
        private ImigrationDataSet imigrationDataSet;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox9;
        public System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dataGridView1;
        //private ImigrationDataSet1 imigrationDataSet1;
        private System.Windows.Forms.BindingSource borderMasterBindingSource;
        //private ImigrationDataSet1TableAdapters.BorderMasterTableAdapter borderMasterTableAdapter;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ToolStripMenuItem referalOfficeClearanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leavingForGoodToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem crewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem impoundsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem flightDelaysToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transfersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem passengerCrewCancellationsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deporteesRemovalsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem passengerInspectionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem flightCrewInspectionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem electronicTravelAuthorizationETAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eTAExcemptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cancelOnArrivalETAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shipPassengerInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inactiveOnWebToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visaStickerProcessToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem bondsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prosecutionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paymentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem maintananceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem performanceAnalysisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem imagesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem overStaysToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem baclogToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem miscelaneousToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem messagesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem changeLocationToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn passportNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nationalityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn reasonDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn counrtDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn createddateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn loggeduserDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.BindingSource imigrationDataSet2BindingSource;
        private ImigrationDataSet2 imigrationDataSet2;
        private System.Windows.Forms.BindingSource imigrationDataSetBindingSource;
        private ImigrationDataSet1 imigrationDataSet1;
        private System.Windows.Forms.BindingSource borderMasterBindingSource1;
        private ImigrationDataSet1TableAdapters.BorderMasterTableAdapter borderMasterTableAdapter;
        private System.Windows.Forms.ToolStripMenuItem startOfDayToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem endOfDayToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeStickerNumberToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem damageStickersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stickerInqueryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sAOProcessEODToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aODailyAttendanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stickerEODBySAOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shipClearanceStickerIssueToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewImageColumn Column1;
    }
}

