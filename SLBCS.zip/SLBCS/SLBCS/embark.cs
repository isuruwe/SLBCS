﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SLBCS
{
    public partial class embark : Form
    {
        public string conf = System.Configuration.ConfigurationManager.AppSettings["conf"];
        SqlConnection con;
        SqlDataAdapter adapt;
        DataTable dt;
        public embark()
        {
            InitializeComponent();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox4_Click(object sender, EventArgs e)
        {
            flights form2 = new flights();
            form2.Show();
            textBox4.Text = form2.TheValue4;
            textBox15.Text = form2.TheValue3;
        }

        private void textBox3_Click(object sender, EventArgs e)
        {
            label22.Text = "Passport Mode";
            panel11.BackColor = Color.Lime;
        }

        private void textBox5_Click(object sender, EventArgs e)
        {
            label22.Text = "Card Mode";
            panel11.BackColor = Color.Lime;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            pictureBox10.Image = null;
            textBox8.Text = "";
            textBox9.Text = "";
            textBox16.Text = "";
            textBox11.Text = "";
            textBox12.Text = "";
            textBox10.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox16.Text = "";
            textBox15.Text = "";
            textBox4.Text = "";
            textBox15.Text = "";
            foreach (Control c in tabControl1.Controls)
            {
                foreach (Control cs in c.Controls)
                {

                    if (cs.GetType() == typeof(System.Windows.Forms.Panel))
                    {
                        cs.BackColor = Color.WhiteSmoke;
                    }
                }
            }
            con = new SqlConnection(conf);
            con.Open();
            adapt = new SqlDataAdapter("select a.PassportNo, a.b " +
"from( " +
  "  select PassportNo as PassportNo, 1 as b from dbo.SIS " +
   "  union all " +
   "                                         select PassportNo, 2 as b from[dbo].[Interpole] " +
"    union all " +
 "   select PassportNo, 3 as b from[dbo].[Prosecution] " +

 "       union all " +
"    select PassportNo, 4 as b from[dbo].WatchList " +
" ) a " +
"where a.PassportNo='" + textBox3.Text + "'", con);
            dt = new DataTable();
            adapt.Fill(dt);
            foreach (DataRow row in dt.Rows)
            {
                string er = row["b"].ToString();
                if (!String.IsNullOrEmpty(er))
                {
                    foreach (Control c in tabControl1.Controls)
                    {
                        foreach (Control cs in c.Controls)
                        {

                            if (cs.GetType() == typeof(System.Windows.Forms.Panel))
                            {
                                textBox14.ForeColor = Color.Red;
                                if (er.Equals("1"))
                                {
                                    textBox14.Text = "User Exist in SIS List!";
                                }
                                if (er.Equals("2"))
                                {
                                    textBox14.Text = "User Exist in Interpole List!";
                                }
                                if (er.Equals("3"))
                                {
                                    textBox14.Text = "User Exist in Prosecution List!";
                                }
                                if (er.Equals("4"))
                                {
                                    textBox14.Text = "User Exist in Watch List!";
                                }

                                cs.BackColor = Color.Gold;
                            }
                        }



                    }


                }
            }

            adapt = new SqlDataAdapter("SELECT       * " +
" FROM            TravelDoc where PassportNo='" + textBox3.Text + "'", con);
            dt = new DataTable();
            adapt.Fill(dt);

            foreach (DataRow row in dt.Rows)
            {
                textBox8.Text = row["LastName"].ToString();
                textBox9.Text = row["FirstName"].ToString();
                textBox16.Text = row["gender"].ToString();
                textBox11.Text = row["dob"].ToString();
                textBox12.Text = row["nicexp"].ToString();
                textBox10.Text = row["nic"].ToString();
                textBox6.Text = row["nationality"].ToString();
                textBox7.Text = row["nationalitycode"].ToString();
                textBox16.Text = row["tdtype"].ToString();
                textBox15.Text = row["endype"].ToString();
            }

            adapt = new SqlDataAdapter("select pimage FROM [Imigration].[dbo].[PaasportImage] where passportno='" + textBox3.Text + "'", con);
            dt = new DataTable();
            adapt.Fill(dt);
            foreach (DataRow row in dt.Rows)
            {
                pictureBox10.Image = ByteToImage((byte[])row["pimage"]);
            }
                con.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(conf);
            con.Open();
            adapt = new SqlDataAdapter("INSERT INTO [dbo].[BorderMaster] ([PassportNo],[Nationality],[Reason],[Counrt],[createddate],[loggeduser],[Status],[FlghtNo],[FlightDate]) " +
 "    VALUES  ('" + textBox3.Text + "','" + textBox6.Text + "','" + textBox13.Text + "','" + Properties.Settings.Default.loc.ToUpper() + "','" + DateTime.Now + "','" + textBox1.Text + "','1','" + textBox4.Text + "','" + textBox15.Text + "') ", con);
            dt = new DataTable();
            adapt.Fill(dt);
            textBox8.Text = "";
            textBox9.Text = "";
            textBox16.Text = "";
            textBox11.Text = "";
            textBox12.Text = "";
            textBox10.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox16.Text = "";
            textBox15.Text = "";
            textBox4.Text = "";
            textBox15.Text = "";
            con.Close();
            MessageBox.Show("Saved!");
        }

        private void embark_Load(object sender, EventArgs e)
        {
            textBox1.Text = Properties.Settings.Default.uname;
            textBox2.Text = DateTime.Now.Date.ToLongDateString();

        }
        public static Bitmap ByteToImage(byte[] blob)
        {
            MemoryStream mStream = new MemoryStream();
            byte[] pData = blob;
            mStream.Write(pData, 0, Convert.ToInt32(pData.Length));
            Bitmap bm = new Bitmap(mStream, false);
            mStream.Dispose();
            return bm;
        }

    }

}
